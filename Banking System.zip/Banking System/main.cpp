#include <iostream>
#include <string>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <vector>

using namespace std;
//struct for bankaccount
struct Account {
    string accountNumber;
    string holderName;
    string bankName;
    string pinNumber; // To store pin number
};

struct User {
    int ID;
    string fullname;
    string email;
    string numberphone;
    string password;
    string numberofcard;
    string nameofbank;
    string name;
    vector <Account> linkedAccounts; // Consistently use this field for accounts
    string ipnPin; // Added ipnPin field to align with functions
    bool isSuspended;
    string contactInfo; // Add this field
};


// Struct for Admin
struct Admin {
    int ID;
    string Name;
    string Email;
    string Role;
    vector<string> Permissions;
};


// Struct for Transaction
struct Transaction {
    int ID;
    int sender;
    int receiver;
    double amount;
    string date;
    string status; // (Successful, Pending, Failed)
};


// Database of users with one predefined user for 100 users with all elements in struct entered by user
User usersInfo[100];
int userCount = 1;
Transaction transactions[100];
int Trans_date;
User newuser;
vector<User> users; //xxxxx
vector<Transaction> transactions1; //xxxxxxxx




//protoypr
void viewUserInfo(const User& user);
void changeIpnPin(User& user);
void addNewAccount(User& user);
void removeAccount(User& user);
void adminDashboard(vector<User>& users, vector<Transaction>& transactions);//xxxxxxxxx




// Function to generate a random OTP
string generateOTP() {
    srand(time(0));
    string otp;
    for (int i = 0; i < 5; i++) {
        otp += to_string(rand() % 10);
    }
    return otp;
}

// Function to save user data to a file
void saveUserToFile(User& user) {
    string filename = user.numberphone + "_user.txt";
    ofstream file(filename, ios::out);

    if (file.is_open()) {
        file << "Full Name: " << user.fullname << "\n";
        file << "Email: " << user.email << "\n";
        file << "Phone Number: " << user.numberphone << "\n";
        file << "Password: " << user.password << "\n";
        file << "Card Number: " << user.numberofcard << "\n";
        file << "Bank Name: " << user.nameofbank << "\n";
        file << "IPN PIN: " << user.ipnPin << "\n";

        file << "Linked Accounts:\n";
        for (const auto& account : user.linkedAccounts) {
            file << "  - Bank: " << account.bankName
                << ", Account Number: " << account.accountNumber
                << ", PIN: " << account.pinNumber << "\n";
        }

        file.close();
        cout << "User data successfully saved to file: " << filename << "\n";
    }
    else {
        cout << "Error: Unable to open file for writing.\n";
    }
}



// Function to check if an email is already registered
bool emailregistered(const string& email) {
    ifstream file("user_database.txt");
    string line;

    if (file.is_open()) {
        while (getline(file, line)) {
            size_t pos = line.find(",");
            if (pos != string::npos) {
                string existingEmail = line.substr(pos + 1, line.find(",", pos + 1) - pos - 1);
                if (existingEmail == email) {
                    file.close();
                    return true;
                }
            }
        }
        file.close();
    }
    return false;
}

// Signup function
void signup() {
    User newuser;
    string otp, enteredOTP;

    cout << "Enter Your Full Name: ";
    cin.ignore();
    getline(cin, newuser.fullname);

    cout << "Enter Your Email: ";
    getline(cin, newuser.email);

    if (emailregistered(newuser.email)) {
        cout << "Email is already registered. Try logging in.\n";
        return;
    }

    cout << "Enter Your Phone Number: ";
    getline(cin, newuser.numberphone);

    cout << "Enter Password: ";
    getline(cin, newuser.password);

    cout << "Enter Your Card Number: ";
    getline(cin, newuser.numberofcard);

    cout << "Enter Name Of Bank: ";
    getline(cin, newuser.nameofbank);

    cout << "Enter Ipn Pin:  ";
    getline(cin, newuser.ipnPin);


    otp = generateOTP();
    cout << "Your OTP is: " << otp << "\n";

    cout << "Enter the OTP sent to you: ";
    getline(cin, enteredOTP);

    if (enteredOTP == otp) {
        saveUserToFile(newuser);
        cout << "Account successfully created! Welcome  in SNAP CASH!\n";
        usersInfo[userCount++] = newuser;
    }
    else {
        cout << "Incorrect OTP. Registration failed.\n";
    }
}



// Login function
bool login(string& loggedInEmail) {
    string email, password;
    string adminemail = "admin@gmail.com";


    cout << "==== User Login ====\n";
    cout << "Please enter your email: ";
    cin >> email;
    if (email == adminemail) {

        adminDashboard(users, transactions1);

    }
    else {
        // Check if the email is in userInfo
        for (int i = 0; i < userCount; i++) {
            if (usersInfo[i].email == email) { // Email matches
                cout << "Email found. Enter your password: ";
                cin >> password;

                // Check if the password is correct
                if (usersInfo[i].password == password) {
                    cout << "Login successful! Welcome, " << usersInfo[i].fullname << ".\n";
                    loggedInEmail = email; // Save logged email
                    User& user = usersInfo[i]; // Reference logged user
                    int choice;
                    do {
                        // Display menu
                        cout << "\n------------------Manage Your Account---------------------\n";
                        cout << "1. View User Information\n";
                        cout << "2. Change IPN PIN\n";
                        cout << "3. Add New Account\n";
                        cout << "4. Remove Account\n";
                        cout << "5. Exit\n";
                        cout << "Enter your choice: ";
                        cin >> choice;

                        switch (choice) {
                        case 1:
                            viewUserInfo(user); // Reusing the view function for a single user
                            break;
                        case 2:
                            changeIpnPin(user);
                            break;
                        case 3:
                            addNewAccount(user);
                            break;
                        case 4:
                            removeAccount(user);
                            break;
                        case 5:
                            cout << "Exiting the system." << endl;
                            break;
                        default:
                            cout << "Invalid choice! Please try again." << endl;
                        }
                    } while (choice != 5);
                    return true;
                }
                else {
                    cout << "Incorrect password.\n";
                    return false;
                }
            }
        }

        cout << "Sorry, we couldn't find that email in our system.\n";
        return false;
    }
}

// Logout function
void logout(string& loggedInEmail) {
    if (!loggedInEmail.empty()) {
        // Find the user's name in our database and say goodbye
        for (int i = 0; i < userCount; i++) {
            if (usersInfo[i].email == loggedInEmail) {
                cout << "Goodbye, " << usersInfo[i].fullname << "! You're now logged out.\n";
                break;
            }
        }
        loggedInEmail.clear(); // Clear the logged-in email
    }
    else {
        cout << "You're not logged in yet.\n";
    }
}

// Function to view user profiles
void viewUserProfiles(const vector<User>& users) {
    cout << "User Profiles:\n";
    for (size_t i = 0; i < users.size(); i++) {
        cout << "ID: " << users[i].ID << ", Name: " << users[i].fullname
            << ", Email: " << users[i].email
            << ", Suspended: " << (users[i].isSuspended ? "Yes" : "No") << endl;
        cout << "Linked Bank Accounts: ";
        for (size_t j = 0; j < users[i].linkedAccounts.size(); j++) {
            cout << users[i].linkedAccounts[j].accountNumber << " ";
        }
        cout << endl;
    }
}



bool validateAccountDetails(const string& bankName, const string& accountNumber) {
    // Mock implementation
    return true;
}

// Function to view user information
void viewUserInfo(const User& user) {
    cout << "Username: " << user.fullname << endl;
    cout << "Phone Number: " << user.numberphone << endl;
    cout << "IPN PIN: " << user.ipnPin << endl;
    cout << "Accounts: " << endl;
    for (const auto& account : user.linkedAccounts) {    //auto can be changed to a specific data type (Account)

        cout << "Bank: " << account.bankName << " | Account Number: " << account.accountNumber << endl;
    }
}
// Function to change IPN pin
void changeIpnPin(User& user) {
    string oldPin, newPin1, newPin2;

    cout << "Enter your current IPN PIN: ";
    cin >> oldPin;

    if (oldPin == user.ipnPin) {
        cout << "Enter your new IPN PIN: ";
        cin >> newPin1;

        cout << "Re-enter your new IPN PIN: ";
        cin >> newPin2;
        if (newPin1 == newPin2) {
            user.ipnPin = newPin1;  // Update the IPN pin
            cout << "Your IPN PIN has been updated successfully!" << endl;
            // Simulate sending a confirmation message
            cout << "Message sent to your phone number: " << user.numberphone << endl;
        }
        else {
            cout << "The new IPN PINs do not match. Try again." << endl;
        }
    }
    else {
        cout << "Incorrect current IPN PIN." << endl;
    }
    saveUserToFile(user);
}

// Function to add a new account
void addNewAccount(User& user) {
    Account newAccount;
    string bankName, cardNumber, pinNumber;

    cout << "Enter the bank name: ";
    cin >> bankName;

    cout << "Enter card number: ";
    cin >> cardNumber;

    cout << "Enter the pin number: ";
    cin >> pinNumber;
    if (!validateAccountDetails(bankName, cardNumber)) {
        cout << "Invalid account details. Please try again." << endl;
        return;
    }
    else {
        // Simulate sending OTP to phone number
        cout << "OTP sent to phone number: " << user.numberphone << endl;
        string otp = generateOTP();
        cout << "Your OTP is: " << otp << "\n";
        cout << "Enter the OTP: ";
        string OTP;
        cin >> OTP;

        // Verify OTP (simplified)
        if (OTP == otp) {
            newAccount.accountNumber = cardNumber;
            newAccount.bankName = bankName;
            newAccount.pinNumber = pinNumber;

            // Add the new account to the user
            user.linkedAccounts.push_back(newAccount);

            cout << "Your account has been added successfully!" << endl;
        }
        else {
            cout << "Incorrect OTP. Account could not be added." << endl;
        }
        saveUserToFile(user);

    }
}


// Function to remove an account
void removeAccount(User& user) {
    string accountNumber;
    cout << "Enter the account number to remove: ";
    cin >> accountNumber;


    bool found = false;
    for (size_t i = 0; i < user.linkedAccounts.size(); ++i) {
        if (user.linkedAccounts[i].accountNumber == accountNumber)//can be replaced by that:for (size_t i = 0; i < user.linkedAccounts.size(); ++i)
        {

            user.linkedAccounts.erase(user.linkedAccounts.begin() + i); // Correct approach using an iterator
            cout << "Account removed successfully!" << endl;
            found = true;
            break; // Exit the loop once the account is removed
        }
    }

    if (!found) {
        cout << "Account not found!" << endl;
    }
    saveUserToFile(user);

}

// Sending and Receiving Money Functions
int sendmoney(int& balance, int& accountorphonenumber, double amount, string transferType);
int receivemoney(int addedamount, int sendernum, int& balance);

// Function to display current balance
void displayBalance(int balance) {
    cout << "Your current balance is: $" << balance << endl;
}


// Transaction management variables and functions
const int maxrow = 10;
string Trans_type[maxrow] = {};
string accountorphonenumber;

void openfile();
//void saveUserToFile( User user ); //SaveToFile
void ListTrans();
void searchTrans(double searchamount, char searchdate, string searchstatus);
double searchamount;
char searchdate;
string searchstatus;



// Function to suspend a user
void suspendUser(vector<User>& users, int userID) {
    for (size_t i = 0; i < users.size(); i++) {
        if (users[i].ID == userID) {
            users[i].isSuspended = true;
            cout << "User with ID " << userID << " has been suspended.\n";
            return;
        }
    }
    cout << "User not found.\n";
}




// Function to flag suspicious transactions
void flagSuspiciousTransactions(const vector<Transaction>& transactions) {
    cout << "Flagging suspicious transactions:\n";
    for (size_t i = 0; i < transactions.size(); i++) {
        if (transactions[i].amount > 100000) { // Example condition for suspicion
            cout << "Suspicious Transaction ID: " << transactions[i].ID
                << ", Amount: $" << transactions[i].amount << endl;
        }
    }
}

// Function to generate reports
void generateReports(const vector<Transaction>& transactions) {
    cout << "Transaction Report:\n";
    for (size_t i = 0; i < transactions.size(); i++) {
        cout << "Transaction ID: " << transactions[i].ID
            << ", Amount: $" << transactions[i].amount
            << ", Status: " << transactions[i].status
            << ", Date: " << transactions[i].date << endl;
    }
}

// Function to handle disputes
void handleDisputes(const vector<Transaction>& transactions) {
    cout << "Handling Disputes:\n";
    for (size_t i = 0; i < transactions.size(); i++) {
        if (transactions[i].status == "Failed" || transactions[i].status == "Unauthorized") {
            cout << "Dispute Transaction ID: " << transactions[i].ID
                << ", Amount: $" << transactions[i].amount
                << ", Status: " << transactions[i].status << endl;
        }
    }
}

// Admin Dashboard
void adminDashboard(vector<User>& users, vector<Transaction>& transactions) {
    int choice = 0;
    while (choice != 6) {
        cout << "\nAdmin Dashboard:\n";
        cout << "1. View User Profiles\n";
        cout << "2. Suspend a User\n";
        cout << "3. Flag Suspicious Transactions\n";
        cout << "4. Generate Reports\n";
        cout << "5. Handle Disputes\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            viewUserProfiles(users);
            break;
        case 2: {
            int userID;
            cout << "Enter User ID to suspend: ";
            cin >> userID;
            suspendUser(users, userID);
            break;
        }
        case 3:
            flagSuspiciousTransactions(transactions);
            break;
        case 4:
            generateReports(transactions);
            break;
        case 5:
            handleDisputes(transactions);
            break;
        case 6:
            cout << "Exiting Admin Dashboard...\n";
            break;
        default:
            cout << "Invalid choice!\n";
        }
    }
}







int main() {
    vector<User> users;
    vector<Transaction> transactions;
    string loggedInEmail = "";
    int balance = 0; // Declare the balance variable here

    // First menu loop for login, logout, and sign-up
    while (true) {
        int choice;
        cout << "\nWelcome to our mini bank system, please choose an option:\n";
        cout << "1. Sign Up\n";
        cout << "2. Login\n";
        cout << "3. Exit\n";

        cout << "Your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            signup();
            break;
        case 2:
            if (login(loggedInEmail)) {
                break;  // Exit the first loop if login is successful
            }
            break;
        case 3:
            cout << "Thanks for using our mini bank system. Goodbye!\n";
            return 0;

        default:
            cout << "Invalid choice. Please try again.\n";
        }

        if (!loggedInEmail.empty()) {
            break;  // Exit the first loop if a user is logged in
        }
    }

    // Second menu loop for the rest of the functionality
    while (true) {
        int choice;
        cout << "\nWelcome to our mini bank system, please choose an option:\n";
        cout << "1. Logout\n";
        cout << "2. Send Money (Create a Transaction)\n";
        cout << "3. Receive Money\n";
        cout << "4. Search Transactions\n";
        cout << "5. Display All Transactions\n";
        cout << "6. Display Current Balance\n";
        cout << "7. Exit and Save\n";
        cout << "Your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            logout(loggedInEmail);
            if (loggedInEmail.empty()) {
                // Return to the first menu if logged out
                main();
            }
            break;
        case 2:
            if (loggedInEmail.empty()) {
                cout << "You need to log in first.\n";
            }
            else {
                cout << "Please Enter your account balance in your credit card: ";
                cin >> balance;
                int accountorphonenumber = 0;
                double amount = 0.0;
                string transferType;
                sendmoney(balance, accountorphonenumber, amount, transferType);
            }
            break;
        case 3:
            if (loggedInEmail.empty()) {
                cout << "You need to log in first.\n";
            }
            else {
                int addedamount, sendernum;
                cout << "Enter the amount received: ";
                cin >> addedamount;
                cout << "Enter sender's account/phone number: ";
                cin >> sendernum;
                receivemoney(addedamount, sendernum, balance);
            }
            break;

        case 4:
            cin.ignore();
            cout << "Please enter the account number to search a transaction: ";
            getline(cin, accountorphonenumber);
            searchTrans(searchamount, searchdate, searchstatus);
            break;

        case 5:
            ListTrans();
            break;
        case 6:
            displayBalance(balance);  // Call the new function
            break;
        case 7:
            cout << "Thanks for using our mini bank system. Goodbye!\n";
            saveUserToFile(newuser);
            return 0;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    }
}


// Implementation of Sending Money
int sendmoney(int& balance, int& accountorphonenumber, double amount, string transferType) {
    int personalphonenumber;
    int currentbalance;
    bool isConfirmed = false;

    while (!isConfirmed) {
        cout << "Please enter your phone number/account number: ";
        cin >> personalphonenumber;
        cout << "Please enter phone number/account number of the receiver: ";
        cin >> accountorphonenumber;
        cout << "Please enter an amount to send ($): ";
        cin >> amount;
        cout << "Choose the type of the transfer (Instant/Scheduled): ";
        cin >> transferType;

        if (transferType == "Scheduled" || transferType == "scheduled") {
            int day;
            int month;
            int year;
            int hour;
            int minute;
            // For scheduled transfer, get date and time, then print "Transaction Pending"

            cout << "Please enter the scheduled date for transfer (Day, Month, Year): ";
            cin >> day >> month >> year;
            cout << "Please enter the scheduled time (Hour, Minute): ";
            cin >> hour >> minute;
            cout << "Transaction Pending! Transfer is scheduled for: " << day << "/" << month << "/" << year
                << " at " << hour << ":" << minute << endl;
            isConfirmed = true;  // Mark the transaction as confirmed (no further review needed)
        }
        else if (transferType == "Instant" || transferType == "instant") {
            currentbalance = balance - amount;
            cout << "Please review the following: \n";
            cout << "Confirming the transaction:\n"
                << "Amount: $" << amount << endl
                << "Receiver details: " << accountorphonenumber << endl
                << "Transfer type: " << transferType << endl;
            cout << "Do you confirm this transaction? (Yes/No): ";
            string confirmation;
            cin >> confirmation;

            if (confirmation == "Yes" || confirmation == "yes") {
                if (amount > 0 && balance >= amount) {
                    cout << "Transaction Successful!" << endl;
                    cout << "$" << amount << " has successfully been sent to " << accountorphonenumber << " using " << transferType << " Transfer Type." << endl;
                    cout << "A message will be sent to " << personalphonenumber << " to confirm the transaction." << endl;
                    balance = currentbalance;
                    cout << "Your current balance: $" << balance << endl;

                    time_t now = time(nullptr);
                    char buffer[26];
                    ctime_s(buffer, sizeof(buffer), &now);
                    cout << "Transaction Time: " << buffer << endl;

                    for (int i = 0; i < maxrow; i++) {
                        if (transactions[i].ID == 0) {  // Find the first empty slot
                            transactions[i].ID = accountorphonenumber;
                            Trans_type[i] = "Sent $" + to_string(amount) + " via " + transferType;
                            break;
                        }
                    }
                    isConfirmed = true;
                }
                else {
                    cout << "Transaction Failed! Not enough balance." << endl;
                }
            }
        }
        else {
            cout << "Invalid transfer type. Please re-enter the details." << endl;
        }
    }
    return 0;
}






// Implementation of Receiving Money
int receivemoney(int addedamount, int sendernum, int& balance) {
    balance += addedamount;
    cout << addedamount << " was sent to your account by " << sendernum << endl;
    cout << "Your account balance is now: $" << balance << endl;

    // Save transaction details
    for (int i = 0; i < maxrow; i++) {
        if (transactions[i].ID == 0) {  // Find the first empty slot
            transactions[i].ID = sendernum;
            Trans_type[i] = "Received $" + to_string(addedamount);
            break;
        }
    }
    return 0;
}




// Listing all transactions
void ListTrans() {
    system("CLS");
    cout << "Current Transactions" << endl;
    cout << "===================================" << endl;
    cout << "NO." << setw(15) << "Account Number" << setw(15) << "Transaction Details" << setw(15) << "Date" << endl;
    cout << "-----------------------------------" << endl;
    int counter = 0;

    for (int i = 0; i < maxrow; i++) {
        if (transactions[i].ID == 0) {
            counter++;
            cout << counter << setw(15) << transactions[i].ID << setw(15) << Trans_type[i] << setw(15) << Trans_date << endl;
        }
    }
    if (counter == 0) {
        cout << "No current transactions" << endl;
    }
    cout << "===================================" << endl;

}


// Searching for a transaction
void searchTrans(double searchamount, char searchdate, string searchstatus) {
    int filter;
    cout << "1-search by amount" << endl << "2-search by date" << endl << "3-search by status" << endl;
    cin >> filter;
    if (filter == 1) {
        for (int i = 0; i < maxrow; i++) {
            if (transactions[i].amount == searchamount) {
                cout << "Transaction Found: amount: " << transactions[i].amount << ", Type: " << Trans_type[i] << ", Account number: " << transactions[i].ID << ", Date: " << Trans_date << endl;
                return;
            }
        }
        cout << "Transaction by amount  " << searchamount << " not found." << endl;
    }

    if (filter == 2) {
        for (int i = 0; i < maxrow; i++) {
            if (Trans_date == searchdate) {
                cout << "Transaction Found: amount: " << transactions[i].amount << ", Type: " << Trans_type[i] << ", Account number: " << transactions[i].ID << ", Date: " << Trans_date << endl;
                return;
            }
        }
        cout << "Transaction by date  " << searchdate << " not found." << endl;
    }


    if (filter == 3) {
        for (int i = 0; i < maxrow; i++) {
            if (transactions[i].status == searchstatus) {
                cout << "Transaction Found: amount: " << transactions[i].amount << ", Type: " << Trans_type[i] << ", Account number: " << transactions[i].ID << ", Date: " << Trans_date << endl;
                return;
            }
        }
        cout << "Transaction by status  " << searchstatus << " not found." << endl;
    }

}